import { PubSub } from 'graphql-subscriptions';

module.exports = new PubSub();
